#include "codeeditor.h"
#include <QPainter>
#include <QTextBlock>
#include <QSyntaxHighlighter>
#include <QTextDocument>
#include <QRegularExpression>

class SyntaxHighlighter : public QSyntaxHighlighter
{
public:
    SyntaxHighlighter(QTextDocument *parent = nullptr);

protected:
    void highlightBlock(const QString &text) override;

private:
    struct HighlightingRule {
        QRegularExpression pattern;
        QTextCharFormat format;
    };
    
    QVector<HighlightingRule> highlightingRules;
    QTextCharFormat keywordFormat;
    QTextCharFormat stringFormat;
    QTextCharFormat commentFormat;
    QTextCharFormat numberFormat;
    QTextCharFormat preprocessorFormat;
    QTextCharFormat functionFormat;
};

SyntaxHighlighter::SyntaxHighlighter(QTextDocument *parent)
    : QSyntaxHighlighter(parent)
{
    // Keyword format
    keywordFormat.setForeground(QColor("#569cd6"));
    keywordFormat.setFontWeight(QFont::Bold);
    
    QStringList keywords;
    keywords << "\\bint\\b" << "\\bfloat\\b" << "\\bchar\\b" << "\\bvoid\\b"
             << "\\bdouble\\b" << "\\bif\\b" << "\\belse\\b" << "\\bwhile\\b"
             << "\\bfor\\b" << "\\bdo\\b" << "\\breturn\\b" << "\\bswitch\\b"
             << "\\bcase\\b" << "\\bdefault\\b" << "\\bstruct\\b" << "\\btypedef\\b"
             << "\\bconst\\b" << "\\bstatic\\b" << "\\bextern\\b" << "\\bsizeof\\b"
             << "\\bbreak\\b" << "\\bcontinue\\b";
    
    foreach (const QString &pattern, keywords) {
        HighlightingRule rule;
        rule.pattern = QRegularExpression(pattern);
        rule.format = keywordFormat;
        highlightingRules.append(rule);
    }
    
    // String format
    stringFormat.setForeground(QColor("#ce9178"));
    HighlightingRule stringRule;
    stringRule.pattern = QRegularExpression("\".*?\"|'.*?'");
    stringRule.format = stringFormat;
    highlightingRules.append(stringRule);
    
    // Number format
    numberFormat.setForeground(QColor("#b5cea8"));
    HighlightingRule numberRule;
    numberRule.pattern = QRegularExpression("\\b\\d+\\.?\\d*\\b");
    numberRule.format = numberFormat;
    highlightingRules.append(numberRule);
    
    // Preprocessor format
    preprocessorFormat.setForeground(QColor("#c586c0"));
    HighlightingRule preprocessorRule;
    preprocessorRule.pattern = QRegularExpression("#\\b\\w+");
    preprocessorRule.format = preprocessorFormat;
    highlightingRules.append(preprocessorRule);
    
    // Comment format
    commentFormat.setForeground(QColor("#6a9955"));
}

void SyntaxHighlighter::highlightBlock(const QString &text)
{
    foreach (const HighlightingRule &rule, highlightingRules) {
        QRegularExpressionMatchIterator matchIterator = rule.pattern.globalMatch(text);
        while (matchIterator.hasNext()) {
            QRegularExpressionMatch match = matchIterator.next();
            setFormat(match.capturedStart(), match.capturedLength(), rule.format);
        }
    }
    
    // Single-line comments
    QRegularExpression singleLineCommentExpression("//[^\n]*");
    QRegularExpressionMatchIterator matchIterator = singleLineCommentExpression.globalMatch(text);
    while (matchIterator.hasNext()) {
        QRegularExpressionMatch match = matchIterator.next();
        setFormat(match.capturedStart(), match.capturedLength(), commentFormat);
    }
    
    // Multi-line comments
    QRegularExpression multiLineCommentStart("/\\*");
    setCurrentBlockState(0);
    
    int startIndex = 0;
    if (previousBlockState() != 1) {
        startIndex = text.indexOf(multiLineCommentStart);
    }
    
    while (startIndex >= 0) {
        QRegularExpression multiLineCommentEnd("\\*/");
        QRegularExpressionMatch endMatch = multiLineCommentEnd.match(text, startIndex);
        int endIndex = endMatch.capturedStart();
        int commentLength;
        
        if (endIndex == -1) {
            setCurrentBlockState(1);
            commentLength = text.length() - startIndex;
        } else {
            commentLength = endIndex - startIndex + endMatch.capturedLength();
        }
        
        setFormat(startIndex, commentLength, commentFormat);
        startIndex = text.indexOf(multiLineCommentStart, startIndex + commentLength);
    }
}

CodeEditor::CodeEditor(QWidget *parent)
    : QPlainTextEdit(parent)
{
    lineNumberArea = new LineNumberArea(this);
    highlighter = new SyntaxHighlighter(document());
    
    connect(this, &CodeEditor::blockCountChanged, this, &CodeEditor::updateLineNumberAreaWidth);
    connect(this, &CodeEditor::updateRequest, this, &CodeEditor::updateLineNumberArea);
    connect(this, &CodeEditor::cursorPositionChanged, this, &CodeEditor::highlightCurrentLine);
    
    updateLineNumberAreaWidth(0);
    highlightCurrentLine();
    
    setFont(QFont("Courier New", 12));
    setTabStopDistance(40);
}

int CodeEditor::lineNumberAreaWidth()
{
    int digits = 1;
    int max = qMax(1, blockCount());
    while (max >= 10) {
        max /= 10;
        ++digits;
    }
    return 3 + fontMetrics().horizontalAdvance(QLatin1Char('9')) * digits;
}

void CodeEditor::updateLineNumberAreaWidth(int /* newBlockCount */)
{
    setViewportMargins(lineNumberAreaWidth(), 0, 0, 0);
}

void CodeEditor::updateLineNumberArea(const QRect &rect, int dy)
{
    if (dy)
        lineNumberArea->scroll(0, dy);
    else
        lineNumberArea->update(0, rect.y(), lineNumberArea->width(), rect.height());
    
    if (rect.contains(viewport()->rect()))
        updateLineNumberAreaWidth(0);
}

void CodeEditor::highlightCurrentLine()
{
    QList<QTextEdit::ExtraSelection> extraSelections;
    
    if (!isReadOnly()) {
        QTextEdit::ExtraSelection selection;
        QColor lineColor = QColor("#2d2d30");
        selection.format.setBackground(lineColor);
        selection.format.setProperty(QTextFormat::FullWidthSelection, true);
        selection.cursor = textCursor();
        selection.cursor.clearSelection();
        extraSelections.append(selection);
    }
    
    setExtraSelections(extraSelections);
}

void CodeEditor::highlightLine(int lineNumber)
{
    QTextCursor cursor(document()->findBlockByLineNumber(lineNumber));
    setTextCursor(cursor);
    ensureCursorVisible();
}

void CodeEditor::lineNumberAreaPaintEvent(QPaintEvent *event)
{
    QPainter painter(lineNumberArea);
    painter.fillRect(event->rect(), QColor("#1e1e1e"));
    
    QTextBlock block = firstVisibleBlock();
    int blockNumber = block.blockNumber();
    int top = blockBoundingGeometry(block).translated(contentOffset()).top();
    int bottom = top + blockBoundingRect(block).height();
    
    painter.setPen(QColor("#858585"));
    
    while (block.isValid() && top <= event->rect().bottom()) {
        if (block.isVisible() && bottom >= event->rect().top()) {
            QString number = QString::number(blockNumber + 1);
            painter.drawText(0, top, lineNumberArea->width(), fontMetrics().height(),
                           Qt::AlignRight, number);
        }
        
        block = block.next();
        top = bottom;
        bottom = top + blockBoundingRect(block).height();
        ++blockNumber;
    }
}

void CodeEditor::resizeEvent(QResizeEvent *e)
{
    QPlainTextEdit::resizeEvent(e);
    
    QRect cr = contentsRect();
    lineNumberArea->setGeometry(QRect(cr.left(), cr.top(), lineNumberAreaWidth(), cr.height()));
}

void CodeEditor::applyDarkTheme()
{
    setStyleSheet(
        "CodeEditor { background-color: #252526; color: #e0e0e0; }"
    );
    highlighter->rehighlight();
}

void CodeEditor::applyLightTheme()
{
    setStyleSheet(
        "CodeEditor { background-color: #f5f5f5; color: #333333; }"
    );
    highlighter->rehighlight();
}

LineNumberArea::LineNumberArea(CodeEditor *editor)
    : QWidget(editor), codeEditor(editor)
{
}

QSize LineNumberArea::sizeHint() const
{
    return QSize(codeEditor->lineNumberAreaWidth(), 0);
}

void LineNumberArea::paintEvent(QPaintEvent *event)
{
    codeEditor->lineNumberAreaPaintEvent(event);
}
