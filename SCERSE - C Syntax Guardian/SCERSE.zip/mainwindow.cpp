#include "mainwindow.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMenuBar>
#include <QToolBar>
#include <QStatusBar>
#include <QFileDialog>
#include <QMessageBox>
#include <QPlainTextEdit>
#include <QListWidget>
#include <QListWidgetItem>
#include <QSplitter>
#include <QApplication>
#include <QStyleFactory>
#include <QFile>
#include <QTextStream>
#include <QSettings>
#include <QDesktopServices>
#include <QUrl>
#include <QRegularExpression>
#include <QTextDocument>
#include "c_error_detector.cpp"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), isModified(false), isDarkMode(true)
{
    setWindowTitle("C Code Analyzer - Qt 6.9.3");
    setWindowIcon(QIcon(":/images/icon.png"));
    resize(1400, 800);
    
    createUI();
    createMenuBar();
    createToolBar();
    setupConnections();
    applyDarkTheme();
    
    analyzeTimer = new QTimer(this);
    analyzeTimer->setSingleShot(true);
    connect(analyzeTimer, &QTimer::timeout, this, &MainWindow::analyzeCode);
    
    // Load sample code
    codeEditor->setPlainText(
        "#include <stdio.h>\n\n"
        "int main() {\n"
        "    int x = 10;\n"
        "    int y = 20;\n"
        "    \n"
        "    printf(\"Sum is: %d\\\\n\", x + y);\n"
        "    \n"
        "    return 0;\n"
        "}\n"
    );
    
    statusBar()->showMessage("Ready");
}

MainWindow::~MainWindow()
{
}

void MainWindow::createUI()
{
    // Central widget
    QWidget *centralWidget = new QWidget(this);
    QHBoxLayout *mainLayout = new QHBoxLayout(centralWidget);
    
    // Splitter for editor and console
    QSplitter *splitter = new QSplitter(Qt::Horizontal);
    
    // Left side - Code Editor
    codeEditor = new CodeEditor(this);
    splitter->addWidget(codeEditor);
    
    // Right side - Error Console
    QWidget *consoleWidget = new QWidget();
    QVBoxLayout *consoleLayout = new QVBoxLayout(consoleWidget);
    
    consoleTab = new QTabWidget();
    
    // Error tab
    errorListWidget = new QListWidget();
    errorListWidget->setAlternatingRowColors(true);
    consoleTab->addTab(errorListWidget, "Errors");
    
    // Info tab
    infoListWidget = new QListWidget();
    infoListWidget->setAlternatingRowColors(true);
    consoleTab->addTab(infoListWidget, "Analysis Info");
    
    consoleLayout->addWidget(consoleTab);
    
    // Status section
    QHBoxLayout *statusLayout = new QHBoxLayout();
    analysisStatus = new QLabel("✓ No errors");
    statusLayout->addWidget(analysisStatus);
    statusLayout->addStretch();
    consoleLayout->addLayout(statusLayout);
    
    splitter->addWidget(consoleWidget);
    splitter->setSizes({900, 500});
    
    mainLayout->addWidget(splitter);
    setCentralWidget(centralWidget);
    
    // Status bar
    statusBar()->addWidget(new QLabel("Ready"), 1);
    cursorLabel = new QLabel("Line: 1, Column: 1");
    statusBar()->addPermanentWidget(cursorLabel);
}

void MainWindow::createMenuBar()
{
    // File menu
    QMenu *fileMenu = menuBar()->addMenu("&File");
    
    QAction *newAction = fileMenu->addAction("&New");
    newAction->setShortcut(Qt::CTRL | Qt::Key_N);
    connect(newAction, &QAction::triggered, this, &MainWindow::newFile);
    
    QAction *openAction = fileMenu->addAction("&Open");
    openAction->setShortcut(Qt::CTRL | Qt::Key_O);
    connect(openAction, &QAction::triggered, this, &MainWindow::openFile);
    
    QAction *saveAction = fileMenu->addAction("&Save");
    saveAction->setShortcut(Qt::CTRL | Qt::Key_S);
    connect(saveAction, &QAction::triggered, this, &MainWindow::saveFile);
    
    QAction *saveAsAction = fileMenu->addAction("Save &As");
    saveAsAction->setShortcut(Qt::CTRL | Qt::SHIFT | Qt::Key_S);
    connect(saveAsAction, &QAction::triggered, this, &MainWindow::saveFileAs);
    
    fileMenu->addSeparator();
    
    QAction *exitAction = fileMenu->addAction("E&xit");
    exitAction->setShortcut(Qt::CTRL | Qt::Key_Q);
    connect(exitAction, &QAction::triggered, this, &QWidget::close);
    
    // View menu
    QMenu *viewMenu = menuBar()->addMenu("&View");
    
    QAction *themeAction = viewMenu->addAction("&Toggle Dark Mode");
    themeAction->setShortcut(Qt::CTRL | Qt::Key_T);
    connect(themeAction, &QAction::triggered, this, &MainWindow::toggleTheme);
    
    // Help menu
    QMenu *helpMenu = menuBar()->addMenu("&Help");
    QAction *aboutAction = helpMenu->addAction("&About");
    connect(aboutAction, &QAction::triggered, [this]() {
        QMessageBox::information(this, "About C Code Analyzer",
            "C Code Analyzer v1.0\n\n"
            "A powerful C code editor with real-time error detection.\n"
            "Built with Qt 6.9.3\n\n"
            "Features:\n"
            "- Syntax Highlighting\n"
            "- Real-time Error Detection\n"
            "- Dark/Light Mode\n"
            "- File Management");
    });
}

void MainWindow::createToolBar()
{
    QToolBar *toolBar = addToolBar("Main Toolbar");
    
    QAction *newAction = toolBar->addAction("New");
    connect(newAction, &QAction::triggered, this, &MainWindow::newFile);
    
    QAction *openAction = toolBar->addAction("Open");
    connect(openAction, &QAction::triggered, this, &MainWindow::openFile);
    
    QAction *saveAction = toolBar->addAction("Save");
    connect(saveAction, &QAction::triggered, this, &MainWindow::saveFile);
    
    toolBar->addSeparator();
    
    QAction *clearAction = toolBar->addAction("Clear Console");
    connect(clearAction, &QAction::triggered, [this]() {
        errorListWidget->clear();
        infoListWidget->clear();
    });
}

void MainWindow::setupConnections()
{
    connect(codeEditor, &CodeEditor::textChanged, this, &MainWindow::onCodeChanged);
    connect(codeEditor, &CodeEditor::cursorPositionChanged, this, &MainWindow::updateStatus);
    connect(errorListWidget, &QListWidget::itemClicked, this, &MainWindow::onErrorClicked);
}

void MainWindow::newFile()
{
    if (maybeSave()) {
        codeEditor->clear();
        currentFile.clear();
        isModified = false;
        setWindowTitle("C Code Analyzer - Qt 6.9.3");
        errorListWidget->clear();
        infoListWidget->clear();
    }
}

void MainWindow::openFile()
{
    QString fileName = QFileDialog::getOpenFileName(this,
        "Open C File", "",
        "C Files (*.c);;Header Files (*.h);;All Files (*)");
    
    if (!fileName.isEmpty()) {
        loadFile(fileName);
    }
}

void MainWindow::loadFile(const QString &filename)
{
    QFile file(filename);
    if (!file.open(QFile::ReadOnly | QFile::Text)) {
        QMessageBox::warning(this, "Error",
            "Cannot open file: " + filename);
        return;
    }
    
    QTextStream in(&file);
    codeEditor->setPlainText(in.readAll());
    file.close();
    
    setCurrentFile(filename);
    updateRecentFiles(filename);
    analyzeCode();
}

void MainWindow::saveFile()
{
    if (currentFile.isEmpty()) {
        saveFileAs();
    } else {
        QFile file(currentFile);
        if (!file.open(QFile::WriteOnly | QFile::Text)) {
            QMessageBox::warning(this, "Error",
                "Cannot save file: " + currentFile);
            return;
        }
        
        QTextStream out(&file);
        out << codeEditor->toPlainText();
        file.close();
        
        isModified = false;
        setWindowTitle(currentFile + " - C Code Analyzer");
        statusBar()->showMessage("File saved", 2000);
    }
}

void MainWindow::saveFileAs()
{
    QString fileName = QFileDialog::getSaveFileName(this,
        "Save C File", "",
        "C Files (*.c);;Header Files (*.h);;All Files (*)");
    
    if (!fileName.isEmpty()) {
        currentFile = fileName;
        saveFile();
    }
}

void MainWindow::onCodeChanged()
{
    if (!isModified) {
        isModified = true;
        if (!currentFile.isEmpty()) {
            setWindowTitle(currentFile + " * - C Code Analyzer");
        }
    }
    
    analyzeTimer->stop();
    analyzeTimer->start(500); // 500ms debounce
}

void MainWindow::analyzeCode()
{
    QString code = codeEditor->toPlainText();
    displayErrors(code);
}

void MainWindow::displayErrors(const QString &code)
{
    // Call your CErrorDetectorEngine
    CErrorDetectorEngine engine;
    AnalysisResult result = engine.analyzeCode(code.toStdString());
    
    errorListWidget->clear();
    
    // Display lexical errors (RED)
    for (const auto& err : result.lexicalErrors) {
        QListWidgetItem *item = new QListWidgetItem(QString::fromStdString(err));
        item->setForeground(QColor("#FF6B6B"));
        errorListWidget->addItem(item);
    }
    
    // Display syntax errors (ORANGE) with suggestions (BLUE)
    for (const auto& [err, sug] : result.syntaxErrors) {
        QListWidgetItem *errItem = new QListWidgetItem(QString::fromStdString(err));
        errItem->setForeground(QColor("#FFA500"));
        errorListWidget->addItem(errItem);
        
        if (!sug.empty()) {
            QListWidgetItem *sugItem = new QListWidgetItem("  → " + QString::fromStdString(sug));
            sugItem->setForeground(QColor("#4DA6FF"));
            errorListWidget->addItem(sugItem);
        }
    }
    
    analysisStatus->setText(QString::number(result.totalErrors) + " errors found");
}


void MainWindow::onErrorClicked(QListWidgetItem *item)
{
    QString text = item->text();
    QRegularExpression rx("Line (\\d+)");
    QRegularExpressionMatch match = rx.match(text);
    
    if (match.hasMatch()) {
        int lineNumber = match.captured(1).toInt();
        codeEditor->highlightLine(lineNumber - 1);
    }
}

void MainWindow::updateStatus()
{
    QTextCursor cursor = codeEditor->textCursor();
    int line = cursor.blockNumber() + 1;
    int column = cursor.positionInBlock() + 1;
    cursorLabel->setText(QString("Line: %1, Column: %2").arg(line).arg(column));
}

void MainWindow::toggleTheme()
{
    isDarkMode = !isDarkMode;
    if (isDarkMode) {
        applyDarkTheme();
    } else {
        applyLightTheme();
    }
}

void MainWindow::applyDarkTheme()
{
    qApp->setStyle(QStyleFactory::create("Fusion"));
    
    QPalette darkPalette;
    darkPalette.setColor(QPalette::Window, QColor("#1e1e1e"));
    darkPalette.setColor(QPalette::WindowText, QColor("#e0e0e0"));
    darkPalette.setColor(QPalette::Base, QColor("#252526"));
    darkPalette.setColor(QPalette::AlternateBase, QColor("#2d2d30"));
    darkPalette.setColor(QPalette::ToolTipBase, QColor("#1e1e1e"));
    darkPalette.setColor(QPalette::ToolTipText, QColor("#e0e0e0"));
    darkPalette.setColor(QPalette::Text, QColor("#e0e0e0"));
    darkPalette.setColor(QPalette::Button, QColor("#3f3f46"));
    darkPalette.setColor(QPalette::ButtonText, QColor("#e0e0e0"));
    darkPalette.setColor(QPalette::BrightText, QColor("#ffffff"));
    darkPalette.setColor(QPalette::Link, QColor("#569cd6"));
    darkPalette.setColor(QPalette::Highlight, QColor("#0e639c"));
    darkPalette.setColor(QPalette::HighlightedText, QColor("#ffffff"));
    
    qApp->setPalette(darkPalette);
    codeEditor->applyDarkTheme();
}

void MainWindow::applyLightTheme()
{
    qApp->setStyle(QStyleFactory::create("Fusion"));
    
    QPalette lightPalette;
    lightPalette.setColor(QPalette::Window, QColor("#ffffff"));
    lightPalette.setColor(QPalette::WindowText, QColor("#333333"));
    lightPalette.setColor(QPalette::Base, QColor("#f5f5f5"));
    lightPalette.setColor(QPalette::AlternateBase, QColor("#e0e0e0"));
    lightPalette.setColor(QPalette::ToolTipBase, QColor("#ffffff"));
    lightPalette.setColor(QPalette::ToolTipText, QColor("#333333"));
    lightPalette.setColor(QPalette::Text, QColor("#333333"));
    lightPalette.setColor(QPalette::Button, QColor("#e0e0e0"));
    lightPalette.setColor(QPalette::ButtonText, QColor("#333333"));
    lightPalette.setColor(QPalette::BrightText, QColor("#000000"));
    lightPalette.setColor(QPalette::Link, QColor("#0000ff"));
    lightPalette.setColor(QPalette::Highlight, QColor("#0078d4"));
    lightPalette.setColor(QPalette::HighlightedText, QColor("#ffffff"));
    
    qApp->setPalette(lightPalette);
    codeEditor->applyLightTheme();
}

void MainWindow::setCurrentFile(const QString &filename)
{
    currentFile = filename;
    isModified = false;
    setWindowTitle(filename + " - C Code Analyzer");
}

void MainWindow::updateRecentFiles(const QString &filename)
{
    // TODO: Implement recent files list
}

bool MainWindow::maybeSave()
{
    if (!isModified) return true;
    
    QMessageBox::StandardButton ret = QMessageBox::warning(this,
        "C Code Analyzer",
        "The document has been modified.\n"
        "Do you want to save your changes?",
        QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
    
    if (ret == QMessageBox::Save)
        saveFile();
    
    return ret != QMessageBox::Cancel;
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    if (maybeSave()) {
        event->accept();
    } else {
        event->ignore();
    }
}
