#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPlainTextEdit>
#include <QListWidget>
#include <QLabel>
#include <QTabWidget>
#include <QTimer>
#include <QSplitter>
#include "codeeditor.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    void closeEvent(QCloseEvent *event) override;

private slots:
    void newFile();
    void openFile();
    void saveFile();
    void saveFileAs();
    void analyzeCode();
    void onErrorClicked(QListWidgetItem *item);
    void toggleTheme();
    void onCodeChanged();
    void updateStatus();

private:
    void createUI();
    void createMenuBar();
    void createToolBar();
    void setupConnections();
    void applyDarkTheme();
    void applyLightTheme();
    void loadFile(const QString &filename);
    void displayErrors(const QString &code);
    void highlightErrorLine(int lineNumber);
    bool maybeSave();
    void setCurrentFile(const QString &filename);
    void updateRecentFiles(const QString &filename);

    CodeEditor *codeEditor;
    QListWidget *errorListWidget;
    QListWidget *infoListWidget;
    QTabWidget *consoleTab;
    QLabel *statusLabel;
    QLabel *cursorLabel;
    QLabel *analysisStatus;
    QTimer *analyzeTimer;
    
    QString currentFile;
    bool isModified;
    bool isDarkMode;
    QVector<int> errorLines;
};

#endif // MAINWINDOW_H
